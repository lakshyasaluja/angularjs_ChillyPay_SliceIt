import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginEmailPageComponent } from './login-email-page.component';

describe('LoginEmailPageComponent', () => {
  let component: LoginEmailPageComponent;
  let fixture: ComponentFixture<LoginEmailPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginEmailPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginEmailPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
