import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
@Component({
  selector: 'app-login-email-page',
  templateUrl: './login-email-page.component.html',
  styleUrls: ['./login-email-page.component.css']
})
export class LoginEmailPageComponent implements OnInit {

  private errormsg:string="";
  private emailaddress="lakshya.saluja@obolustech.com";
  constructor(private route:Router) { }

  ngOnInit() {
  }

  onClick(email)
  {
    if(email=="")
    {
      this.errormsg="Plz Enter Email Address";
    }
    else if(!(email==this.emailaddress))
    {
      this.errormsg="Email Address is InCorrect";
    }
    else
    {
      this.route.navigate([
        '/login-password'
      ]);
    }
    
  }
}
