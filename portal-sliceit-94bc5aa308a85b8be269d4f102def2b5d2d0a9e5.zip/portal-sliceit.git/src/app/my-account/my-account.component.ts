import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-my-account',
  templateUrl: './my-account.component.html',
  styleUrls: ['./my-account.component.css']
})
export class MyAccountComponent implements OnInit {

  private user:object;
  private isMobileHidden:boolean=false;
  private isEmailHidden:boolean=false;
  private isPasswordHidden:boolean=false;
  private isNewPasswordHidden:boolean=false;
  private invalidPasswordMsg:string="";
  private isHidden=true;
  constructor(private http:HttpClient) { }
  ngOnInit() {
    this.http.get("assets/json/my_account.json")
    .subscribe(data => this.user =data);
  }

  changeEmail()
  {
    this.isEmailHidden=true;
  }
  changeMobile()
  {
    this.isMobileHidden=true;
  }
  changePassword()
  {
    this.isPasswordHidden=true;
    this.isHidden=false;
  }

  checkPassword(currentPassword)
  {
    if(currentPassword==this.user["password"])
    {
      this.isPasswordHidden=false;
      this.isNewPasswordHidden=true;
      this.invalidPasswordMsg="";
    }
    else{
      this.invalidPasswordMsg="Worng Password";
    
    }

  }
  updatePassword(newPassword)
  {
    this.user["password"]=newPassword;
    this.isHidden=true;
    this.isNewPasswordHidden=false;
  }
  updateEmail(email)
  {
    this.user["emailAddress"]=email;
    this.isEmailHidden=false;
  }
  updateMobile(number)
  {
    this.user["mobileNumber"]=number;
    this.isMobileHidden=false;
  }
  updateAddress(address1,address2,address3,pincode,houseNumber)
  {
    this.user["address1"]=address1.value;
    this.user["address2"]=address2.value;
    this.user["address3"]=address3.value;
    this.user["pincode"]=pincode.value;
    this.user["houseNumber"]=houseNumber.value;
    alert("Address Updated  ");

  }
}
