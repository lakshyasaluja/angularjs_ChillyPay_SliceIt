import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register-verification-page',
  templateUrl: './register-verification-page.component.html',
  styleUrls: ['./register-verification-page.component.css']
})
export class RegisterVerificationPageComponent implements OnInit {
  private errormsg:string="";
  constructor(private route:Router) { }

  ngOnInit() {
  }
onClick(verificationno)
{
  if(verificationno=="")
  {
    this.errormsg="Plz Enter Verification Number";
  }
  else if(verificationno.length != 6)
  {
    this.errormsg="Plz Enter Six Digit Verification Number";
  }
  else{
    this.route.navigate(['/dashboard']);
  }
}
}
