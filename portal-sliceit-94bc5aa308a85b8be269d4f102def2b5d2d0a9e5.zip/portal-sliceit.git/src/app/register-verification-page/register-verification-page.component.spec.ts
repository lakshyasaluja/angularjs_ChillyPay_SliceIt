import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterVerificationPageComponent } from './register-verification-page.component';

describe('RegisterVerificationPageComponent', () => {
  let component: RegisterVerificationPageComponent;
  let fixture: ComponentFixture<RegisterVerificationPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegisterVerificationPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterVerificationPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
