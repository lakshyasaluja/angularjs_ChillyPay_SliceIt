import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginPasswordPageComponent } from './login-password-page.component';

describe('LoginPasswordPageComponent', () => {
  let component: LoginPasswordPageComponent;
  let fixture: ComponentFixture<LoginPasswordPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginPasswordPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginPasswordPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
