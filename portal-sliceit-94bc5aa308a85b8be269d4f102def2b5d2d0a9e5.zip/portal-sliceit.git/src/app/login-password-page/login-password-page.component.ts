import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
@Component({
  selector: 'app-login-password-page',
  templateUrl: './login-password-page.component.html',
  styleUrls: ['./login-password-page.component.css']
})
export class LoginPasswordPageComponent implements OnInit {

  private errormsg="";
  constructor(private route:Router) { }

  ngOnInit() {
  }

  onClick(password)
  {
    if(password=="")
    {
      this.errormsg="Plz Enter Password";
    }
    else if(!(password=="123456"))
    {
      this.errormsg="Password is Incorrect";
    }
    else
    {
      this.route.navigate(
        ['/dashboard']
      );
    }

  }
}
