import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dashboard-page',
  templateUrl: './dashboard-page.component.html',
  styleUrls: ['./dashboard-page.component.css']
})
export class DashboardPageComponent implements OnInit {
private orders:any=[];
  constructor(private http:HttpClient) { }

  ngOnInit() {
    this.http.get("assets/json/orders.json")
    .subscribe(data => this.orders =data);
  }

}
