import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-payment-schedule',
  templateUrl: './payment-schedule.component.html',
  styleUrls: ['./payment-schedule.component.css']
})
export class PaymentScheduleComponent implements OnInit {

  private payments:any=[];
  constructor(private http:HttpClient) { }

  ngOnInit() {
    this.http.get("assets/json/payment_schedule.json")
    .subscribe(data => this.payments = data);
  }

}
