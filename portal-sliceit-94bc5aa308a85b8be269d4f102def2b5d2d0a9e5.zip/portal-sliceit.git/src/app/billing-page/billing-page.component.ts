import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-billing-page',
  templateUrl: './billing-page.component.html',
  styleUrls: ['./billing-page.component.css']
})
export class BillingPageComponent implements OnInit {

  private isHidden:boolean=false;
  private billings:any=[];
  constructor(private http:HttpClient) { }

  ngOnInit() {
    this.http.get("assets/json/billing.json")
    .subscribe(data => this.billings =data);
  }
  onClick(cardNumber)
  {
    for(var i=0;i<this.billings.length;i++)
    {
      if(this.billings[i]["number"]==cardNumber)
      {
        
        var flag=confirm("Are You sure? Do You Want To Delete This Card Infomation?");
        if(flag==true)
        {
          this.billings.splice(i,1);
        }
      }
    }
  }
  onMakePrefrered(cardNumber)
  {
    for(var i=0;i<this.billings.length;i++)
    {
      if(this.billings[i]["number"]==cardNumber)
      {
        this.billings[i]["prefreredCard"]="yes";
      }
      else
      {
        this.billings[i]["prefreredCard"]="no";
      }
    }
  }

}
