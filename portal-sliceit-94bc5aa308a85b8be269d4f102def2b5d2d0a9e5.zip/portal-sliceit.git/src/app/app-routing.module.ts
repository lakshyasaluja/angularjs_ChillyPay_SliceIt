import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginEmailPageComponent } from './login-email-page/login-email-page.component';
import { LoginPasswordPageComponent } from './login-password-page/login-password-page.component';
import { DashboardPageComponent } from './dashboard-page/dashboard-page.component';
import { RegisterEmailPageComponent } from './register-email-page/register-email-page.component';
import { RegisterPhonenoPageComponent } from './register-phoneno-page/register-phoneno-page.component';
import { RegisterVerificationPageComponent } from './register-verification-page/register-verification-page.component';
import { PaymentScheduleComponent } from './payment-schedule/payment-schedule.component';
import { MyAccountComponent } from './my-account/my-account.component';
import { BillingPageComponent } from './billing-page/billing-page.component';
import { OrderPageComponent } from './order-page/order-page.component';

const routes: Routes = [
  {path: '',component:LoginEmailPageComponent},
  {path:'login-password',component:LoginPasswordPageComponent},
  {path:'dashboard',component:DashboardPageComponent},
  {path:'register-email',component:RegisterEmailPageComponent},
  {path:'register-phoneno',component:RegisterPhonenoPageComponent},
  {path:'register-verification',component:RegisterVerificationPageComponent},
  {path:'payment-schedule',component:PaymentScheduleComponent},
  {path:'my-account',component:MyAccountComponent},
  {path:'billing',component:BillingPageComponent},
  {path:'order',component:OrderPageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponent=[LoginEmailPageComponent,LoginPasswordPageComponent,DashboardPageComponent
  ,RegisterEmailPageComponent,RegisterPhonenoPageComponent,RegisterVerificationPageComponent,PaymentScheduleComponent
  ,MyAccountComponent,BillingPageComponent,OrderPageComponent];
