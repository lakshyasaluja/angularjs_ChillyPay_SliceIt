import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterPhonenoPageComponent } from './register-phoneno-page.component';

describe('RegisterPhonenoPageComponent', () => {
  let component: RegisterPhonenoPageComponent;
  let fixture: ComponentFixture<RegisterPhonenoPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegisterPhonenoPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterPhonenoPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
