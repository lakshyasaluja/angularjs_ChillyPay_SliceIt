import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
@Component({
  selector: 'app-register-phoneno-page',
  templateUrl: './register-phoneno-page.component.html',
  styleUrls: ['./register-phoneno-page.component.css']
})
export class RegisterPhonenoPageComponent implements OnInit {
private errormsg:string="";
  constructor(private route:Router) { }

  ngOnInit() {
  }
onClick(phoneno)
{
  if(phoneno=="")
  {
    this.errormsg="Plz Enter Phone Number";
  }
  else if(phoneno.length < 10 || phoneno.length > 12)
  {
    this.errormsg="Plz Enter A Valid Phone Number";
  }
  else{
    this.route.navigate(['/register-verification']);
  }
}
}
