import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register-email-page',
  templateUrl: './register-email-page.component.html',
  styleUrls: ['./register-email-page.component.css']
})
export class RegisterEmailPageComponent implements OnInit {
private errormsg:string="";
  constructor(private route:Router) { }

  ngOnInit() {
  }
  onClick(email)
  {

    if(email=="")
    {
      this.errormsg="Plz Enter Email Address";
    }
    else{
this.route.navigate(['/register-phoneno']);
    }
  }

}
